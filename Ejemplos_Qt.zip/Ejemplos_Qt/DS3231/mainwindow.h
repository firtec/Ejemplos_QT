#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QMessageBox>
#include <QPushButton>
# include <QTimer>
#include <QTime>
#include <QDate>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();
    void UnSegundo();


    void on_actualizar_clicked();

private:
    Ui::MainWindow *ui;
    QSerialPort *arduino;
    QTimer *timer = new QTimer(this);
    QByteArray byte_arrray = "       ";
    QString as;
    bool bandera = false;
    bool error = false;
};

#endif // MAINWINDOW_H
