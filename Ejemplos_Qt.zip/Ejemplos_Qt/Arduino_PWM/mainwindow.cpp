#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    Q_FOREACH(QSerialPortInfo port, QSerialPortInfo::availablePorts()) {
                 ui->puerto->addItem(port.portName());
             }
       ui->baudBox->addItem(QStringLiteral("1200"), QSerialPort::Baud1200);
       ui->baudBox->addItem(QStringLiteral("2400"), QSerialPort::Baud2400);
       ui->baudBox->addItem(QStringLiteral("4800"), QSerialPort::Baud4800);
       ui->baudBox->addItem(QStringLiteral("9600"), QSerialPort::Baud9600);
       ui->baudBox->addItem(QStringLiteral("2400"), QSerialPort::Baud19200);
       ui->baudBox->addItem(QStringLiteral("38400"), QSerialPort::Baud38400);
       ui->baudBox->addItem(QStringLiteral("57600"), QSerialPort::Baud57600);
       ui->baudBox->addItem(QStringLiteral("115200"), QSerialPort::Baud115200);

          statusBar()->showMessage(tr("Desconectado!"));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    if(bandera == false){
               //arduino = new QSerialPort(this);
            // arduino->setPortName(ui->puerto->currentText());
              arduino = new QSerialPort(ui->puerto->currentText()); // Puerto asignado con el combo BOX
               arduino->open(QIODevice::ReadWrite);
               if(!arduino->isOpen())
               {
                   error = true;
                   QMessageBox::warning(this, "ERROR", "EL PUERTO YA ESTA ABIERTO O NO EXISTE!!!");
               }

       if(error == false){
           arduino->clear(QSerialPort::AllDirections);  // Limpar buffer del puerto COMx
           arduino->open(QIODevice::ReadWrite);
           arduino->setBaudRate(ui->baudBox->currentData().toInt());
           arduino->setDataBits(QSerialPort::Data8);
           arduino->setFlowControl(QSerialPort::NoFlowControl);
           arduino->setParity(QSerialPort::NoParity);
           arduino->setStopBits(QSerialPort::OneStop);
          // QObject::connect(arduino, SIGNAL(readyRead()), this, SLOT(LeerSerial()));
           ui->puerto->setEnabled(false);
           ui->baudBox->setEnabled(false);
           ui->horizontalSlider->setEnabled(true);
           bandera = true;
           arduino->write("c");
           statusBar()->showMessage(tr("Conectado %1 a %2 baudios, %3 bits, %4 stop, s/p")
            .arg(arduino->portName()).arg(arduino->baudRate()).arg(arduino->dataBits()).arg(arduino->stopBits()));//.arg(arduino->parity()));

           ui->pushButton->setText("Desconectar");


          }
       error = false;
       }else{
               arduino->write("c");
               arduino->clear(QSerialPort::AllDirections);   // Limpar buffer del puerto COMx
               arduino->close();   // Cerrar el puerto COMx
               bandera = false;    // Cambiar bandera de estado
               ui->pushButton->setText("Conectar");    // Cambiar texto del boton
               statusBar()->showMessage(tr("Desconectado!"));  // Cambiar texto en barra de estado
               ui->puerto->setEnabled(true);   // Activar selección de puertos
               ui->baudBox->setEnabled(true);  // Activar selección de baudios
               ui->horizontalSlider->setEnabled(false);
            }
}

void MainWindow::on_horizontalSlider_valueChanged(int value)
{
    arduino->putChar(value);
}
