#ifndef MAINFORM_H
#define MAINFORM_H

#include <QMainWindow>
#include <otroform.h>


namespace Ui {
class MainForm;
}

class MainForm : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainForm(QWidget *parent = nullptr);
    ~MainForm();

private slots:
//public slots:
   // void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::MainForm *ui;
    OtroForm * Window2 = new OtroForm();

};

#endif // MAINFORM_H
