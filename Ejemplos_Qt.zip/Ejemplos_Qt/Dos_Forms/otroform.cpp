#include "otroform.h"
#include "ui_otroform.h"
#include "mainform.h"

OtroForm::OtroForm(QWidget *parent) :
    QWidget(parent),
    ui2(new Ui::OtroForm)
{
    ui2->setupUi(this);
}

OtroForm::~OtroForm()
{
    delete ui2;
}
void OtroForm::datosRemotos()
 {
      ui2->texto2->setText("Hola Firtec!!");

}
