#include "mainform.h"
#include "ui_mainform.h"
#include "otroform.h"
//#include "ui_otroform.h"

MainForm::MainForm(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainForm)
{
    ui->setupUi(this);
    connect(ui->pushButton, SIGNAL(clicked()), Window2, SLOT(datosRemotos()));
  //  connect(ui->pushButton, SIGNAL(released()), Window2, SLOT(datosRemotos()));
  //  connect(ui->pushButton, SIGNAL(toggled()), Window2, SLOT(datosRemotos()));

}

MainForm::~MainForm()
{
    delete ui;
 }

//void MainForm::on_pushButton_clicked()
//{
 //  Window2->show();
   //pt = ui->Window2;
  // this->hide();    // Oculta el fomulario de origen
  // this->show();    // Muestra el formulario origen
  // this->close();   // Cierra el formulario de origen

//}

void MainForm::on_pushButton_2_clicked()
{
   Window2->show();
}
