#ifndef OTROFORM_H
#define OTROFORM_H

#include <QWidget>

namespace Ui {
class OtroForm;
}

class OtroForm : public QWidget
{
    Q_OBJECT

public:
    explicit OtroForm(QWidget *parent = nullptr);
    ~OtroForm();
//    Ui::OtroForm *ui2;
private slots:
//public slots:
    void datosRemotos();

private:
    Ui::OtroForm *ui2;
};

#endif // OTROFORM_H
