#include "mainform.h"
#include <QApplication>
#include "otroform.h"
#include "ui_otroform.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainForm w;
    w.show();

    return a.exec();
}
