/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionCerrar;
    QAction *actionAjustes;
    QWidget *centralWidget;
    QLabel *texto;
    QPushButton *pushButton;
    QLabel *label_3;
    QFrame *line;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLabel *temp;
    QWidget *widget1;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLabel *pres;
    QMenuBar *menuBar;
    QMenu *menuSalir;
    QMenu *menuConfiguraci_n;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(393, 300);
        actionCerrar = new QAction(MainWindow);
        actionCerrar->setObjectName(QString::fromUtf8("actionCerrar"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/application-exit.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCerrar->setIcon(icon);
        actionAjustes = new QAction(MainWindow);
        actionAjustes->setObjectName(QString::fromUtf8("actionAjustes"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/settings.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAjustes->setIcon(icon1);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        texto = new QLabel(centralWidget);
        texto->setObjectName(QString::fromUtf8("texto"));
        texto->setGeometry(QRect(300, 70, 71, 61));
        QFont font;
        font.setPointSize(12);
        texto->setFont(font);
        texto->setStyleSheet(QString::fromUtf8("border-image: url(:/Qt.png);"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setEnabled(true);
        pushButton->setGeometry(QRect(40, 160, 321, 51));
        QPalette palette;
        QBrush brush(QColor(0, 170, 127, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        QBrush brush1(QColor(120, 120, 120, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        pushButton->setPalette(palette);
        QFont font1;
        font1.setPointSize(16);
        font1.setBold(true);
        font1.setWeight(75);
        pushButton->setFont(font1);
        pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(30, 10, 331, 31));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label_3->setPalette(palette1);
        QFont font2;
        font2.setPointSize(28);
        label_3->setFont(font2);
        label_3->setAlignment(Qt::AlignCenter);
        line = new QFrame(centralWidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(10, 40, 371, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        widget = new QWidget(centralWidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(30, 70, 247, 37));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font3;
        font3.setPointSize(22);
        label->setFont(font3);

        horizontalLayout->addWidget(label);

        temp = new QLabel(widget);
        temp->setObjectName(QString::fromUtf8("temp"));
        temp->setFont(font3);

        horizontalLayout->addWidget(temp);

        widget1 = new QWidget(centralWidget);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(30, 110, 258, 37));
        horizontalLayout_2 = new QHBoxLayout(widget1);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(widget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font3);

        horizontalLayout_2->addWidget(label_2);

        pres = new QLabel(widget1);
        pres->setObjectName(QString::fromUtf8("pres"));
        pres->setFont(font3);

        horizontalLayout_2->addWidget(pres);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 393, 21));
        menuSalir = new QMenu(menuBar);
        menuSalir->setObjectName(QString::fromUtf8("menuSalir"));
        menuConfiguraci_n = new QMenu(menuBar);
        menuConfiguraci_n->setObjectName(QString::fromUtf8("menuConfiguraci_n"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        QPalette palette2;
        QBrush brush2(QColor(255, 0, 0, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette2.setBrush(QPalette::Active, QPalette::WindowText, brush2);
        palette2.setBrush(QPalette::Inactive, QPalette::WindowText, brush2);
        palette2.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        statusBar->setPalette(palette2);
        QFont font4;
        font4.setPointSize(11);
        font4.setItalic(true);
        statusBar->setFont(font4);
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuSalir->menuAction());
        menuBar->addAction(menuConfiguraci_n->menuAction());
        menuSalir->addAction(actionCerrar);
        menuConfiguraci_n->addAction(actionAjustes);
        mainToolBar->addAction(actionCerrar);
        mainToolBar->addAction(actionAjustes);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", " BMP280 UART", nullptr));
        actionCerrar->setText(QApplication::translate("MainWindow", "Cerrar", nullptr));
        actionAjustes->setText(QApplication::translate("MainWindow", "Ajustes", nullptr));
        texto->setText(QString());
        pushButton->setText(QApplication::translate("MainWindow", "Conectar con Arduino", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "Sensor BMP280", nullptr));
        label->setText(QApplication::translate("MainWindow", "Temperatura: ", nullptr));
        temp->setText(QApplication::translate("MainWindow", "00.0", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "Presi\303\263n hPa:  ", nullptr));
        pres->setText(QApplication::translate("MainWindow", "000.0", nullptr));
        menuSalir->setTitle(QApplication::translate("MainWindow", "Salir", nullptr));
        menuConfiguraci_n->setTitle(QApplication::translate("MainWindow", "Configuraci\303\263n", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
