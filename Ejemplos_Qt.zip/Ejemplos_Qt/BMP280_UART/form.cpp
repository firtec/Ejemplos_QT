#include "form.h"
#include "ui_form.h"
#include "mainwindow.h"
#include <QMainWindow>
//#include "mainwindow.cpp"

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);
   // MainWindow * Window1 = new MainWindow();

    Q_FOREACH(QSerialPortInfo port, QSerialPortInfo::availablePorts()) {
                     ui->puerto->addItem(port.portName());
                 }
           ui->baudBox->addItem(QStringLiteral("1200"), QSerialPort::Baud1200);
           ui->baudBox->addItem(QStringLiteral("2400"), QSerialPort::Baud2400);
           ui->baudBox->addItem(QStringLiteral("4800"), QSerialPort::Baud4800);
           ui->baudBox->addItem(QStringLiteral("9600"), QSerialPort::Baud9600);
           ui->baudBox->addItem(QStringLiteral("2400"), QSerialPort::Baud19200);
           ui->baudBox->addItem(QStringLiteral("38400"), QSerialPort::Baud38400);
           ui->baudBox->addItem(QStringLiteral("57600"), QSerialPort::Baud57600);
           ui->baudBox->addItem(QStringLiteral("115200"), QSerialPort::Baud115200);

           // QObject::connect(ui->pushButton, SIGNAL(clicked()), Window1, SLOT(ajustarUART()));
            QObject::connect(ui->config, SIGNAL(clicked()), SLOT(datosRemotos()));

           //  QObject::connect(ui->pushButton, SIGNAL(clicked()), Window1, SLOT(MainWindow::ajustarUART()));
           //connect(ui->pushButton, SIGNAL(clicked()), SLOT(MainWindow::ajustarUART()));

}

Form::~Form()
{
    delete ui;
}




void Form::datosRemotos()
 {
     COMx = ui->puerto->currentText();
     BAUDIOS = ui->baudBox->currentData().toInt();
     this->close();
    // Window1->ui->pushButton->setEnabled(true);

}


void Form::on_config_clicked()
{


}
