#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "form.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    sample_palette.setColor(QPalette::WindowText, Qt::blue);
        ui->temp->setPalette(sample_palette);
        ui->temp->setText("00.0");
        ui->pres->setPalette(sample_palette);
        ui->pres->setText("000.0");


    arduino = new QSerialPort(this);
    QObject::connect(arduino, SIGNAL(readyRead()), this, SLOT(LeerSerial()));
    QObject::connect(ui->pushButton, SIGNAL(clicked()), Window2, SLOT(datosRemotos()));
    QObject::connect(timer,SIGNAL(timeout()),this,SLOT(cambiarBandera()));

    statusBar()->showMessage(tr("Desconectado!"));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionCerrar_triggered()
{
    QApplication::quit();
}

void MainWindow::on_actionAjustes_triggered()
{
   if(bandera){
     QMessageBox::warning(this, "CONECTADO!!", "NO PUEDE CAMBIAR LA CONFIGURACIÓN");
   }
else
    Window2->show();
}


/**************************************************************
*   Esta función procesa los datos recibidos desde el puerto
*   COM seleccionado.
*   Dependendiendo de la bandera "estado" los datos se ven en
*   la posición correspondiente en la ventana.
***************************************************************/
void MainWindow::LeerSerial()
{

 if(estado == 1){
    //serialData1 = arduino->readAll();
    serialData1 = arduino->read(4);
    ui->temp->setText(serialData1);
    serialData1.clear();
    serialData2.clear();
    estado = 2;
  }
    //else{
 else if(estado == 2) {
      // serialData2 = arduino->readAll();
       serialData2 = arduino->read(6);
       ui->pres->setText(serialData2);
       estado = 0;
       serialData1.clear();
       serialData2.clear();

    }
}



void MainWindow::on_pushButton_clicked()
{
    if(bandera == false){


               //arduino = new QSerialPort(ui->puerto->currentText()); // Puerto asignado con el combo BOX
       // arduino = new QSerialPort(this);
        arduino->setPortName(Window2->COMx);
        arduino->setBaudRate(Window2->BAUDIOS);
        arduino->open(QIODevice::ReadWrite);
        arduino->setDataBits(QSerialPort::Data8);
        arduino->setFlowControl(QSerialPort::NoFlowControl);
        arduino->setParity(QSerialPort::NoParity);
        arduino->setStopBits(QSerialPort::OneStop);
      //  QObject::connect(arduino, SIGNAL(readyRead()), this, SLOT(LeerSerial()));

        arduino->open(QIODevice::ReadWrite);
                if(!arduino->isOpen())
                {
                    error = true;
                    QMessageBox::warning(this, "ERROR", "EL PUERTO YA ESTA ABIERTO O NO EXISTE!!!");
                }
    if(error == false){
                bandera = true;
                arduino->write("c");
                statusBar()->showMessage(tr("Conectado %1 a %2 baudios, %3 bits, %4 stop, s/p")
                 .arg(arduino->portName()).arg(arduino->baudRate()).arg(arduino->dataBits()).arg(arduino->stopBits()));//.arg(arduino->parity()));

                ui->pushButton->setText("Desconectar");
                serialData1.clear();
               // arduino->clear(QSerialPort::AllDirections);
                //connect(timer,SIGNAL(timeout()),this,SLOT(cambiarBandera()));
                estado = 0;
                timer->start(1000);
               }
    error = false;
       }else{
               arduino->write("c");
               arduino->clear(QSerialPort::AllDirections);   // Limpar buffer del puerto COMx
               arduino->close();   // Cerrar el puerto COMx
               bandera = false;    // Cambiar bandera de estado
               ui->pushButton->setText("Conectar con Arduino");    // Cambiar texto del boton
               statusBar()->showMessage(tr("Desconectado!"));  // Cambiar texto en barra de estado
               ui->temp->setText("00.0");         // Limpiar indicadores
               ui->pres->setText("000.0");
               serialData1.clear();            // Limpiar buffer
               timer->stop();                  // Detener el timer
             //  ui->mainToolBar->setEnabled(true);
               //Window2->setEnabled(true);

            }
    }

/**************************************************************
*   Esta función se ejecuta cada vez que el timer se desborda.
*   Su trabajo es enviar los caracteres de control para que
*   Arduino transmita la temperatura o la presión según sea el
*   caso.
***************************************************************/
void MainWindow::cambiarBandera()
{
if(estado == 0){
    arduino->write("c");
    arduino->write("a");
    //arduino->flush();
    estado = 1;
}
else if(estado == 2) {
//else{
    arduino->write("c");
    arduino->write("b");
    // arduino->flush();
 }
}








