#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QMessageBox>
#include <QByteArray>
#include <QPushButton>
# include <QTimer>
#include "form.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QTimer *timer = new QTimer(this); // Constructor del Temporizador
    QSerialPort *arduino;
    unsigned char estado = 0;
    QByteArray serialData1;
    QByteArray serialData2;
    bool bandera = false;
    bool error = false;

signals:
    void changeLabel();
    void valueChanged(double newValue);

private slots:
    void on_actionCerrar_triggered();
    void on_actionAjustes_triggered();
    void on_pushButton_clicked();
    void LeerSerial();
    void cambiarBandera();

//public:
private:
    Ui::MainWindow *ui;
    Form * Window2 = new Form();
    QPalette sample_palette;

};

#endif // MAINWINDOW_H
