#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QMainWindow>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QMessageBox>


namespace Ui {
class Form;
}

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

//private slots:
public slots:
      void datosRemotos();

//private:
public:
    Ui::Form *ui;
    //QMainWindow * Window1 = new QMainWindow();
   QMainWindow * Window1 = new QMainWindow();

    QString COMx;
    int BAUDIOS;

private slots:
    void on_config_clicked();
};

#endif // FORM_H
