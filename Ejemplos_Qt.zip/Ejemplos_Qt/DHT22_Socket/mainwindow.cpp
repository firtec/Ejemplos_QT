#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QNetworkInterface>
#include <QUdpSocket>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

   
        QList<QHostAddress> list = QNetworkInterface::allAddresses();
        foreach (const QHostAddress &address, QNetworkInterface::allAddresses()) {
                        if (address.protocol() == QAbstractSocket::IPv4Protocol && address != QHostAddress(QHostAddress::LocalHost))
                        string = address.toString();
                        ui->iplocal->setText(string);
           }

        QHostAddress address(QHostAddress::Any);
        address.setAddress(string);
        socket = new QUdpSocket(this);
        socket->bind(address , 30000); // Conecta una dirección y un puerto a un socket
        statusBar()->showMessage(tr("Desconectado!!"));
        connect(socket, SIGNAL(readyRead()), this, SLOT(processPendingDatagrams()),Qt::QueuedConnection);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::processPendingDatagrams()
 {

    QHostAddress sender;
     uint16_t port;
     QByteArray datagram;
     QString dato1;
     QString dato2;
     datagram.resize(socket->pendingDatagramSize());  // Se determina el tamaño del datagrama a leer.
    
    while (socket->hasPendingDatagrams()) {
        socket->readDatagram(datagram.data(),datagram.size(),&sender,&port);
        ui->IP->setText(sender.toString());             // Mustra la IP a la que se conecta
        QString recibido_socket(datagram);              // Convierte QByteArray a QString
        QStringList datos = recibido_socket.split(","); // Busca la marca separadora de campos ","
        ui->l1->setText(datos[0]);
        ui->l2->setText(datos[1]);
        statusBar()->showMessage(tr(" Conectado en puerto %1").arg(port));

    }
}
