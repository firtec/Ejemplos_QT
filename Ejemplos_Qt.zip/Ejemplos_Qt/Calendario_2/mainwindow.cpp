#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTextStream>
#include <QTime>
#include <QDate>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QObject::connect(timer,SIGNAL(timeout()),this,SLOT(actualizar()));
    timer->start(1000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::actualizar()
{
   // QDate cd = QDate::currentDate();
    QTime ct = QTime::currentTime();

   // ui->label->setText(cd.toString());
    ui->label2->setText(ct.toString());

}


