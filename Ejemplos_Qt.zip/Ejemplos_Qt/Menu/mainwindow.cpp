#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTextStream>  // Necesario para el manejo de cadenas
#include <QFile>        // Necesario para el manejo de archivos


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionAbrir_triggered()
{
    QFile archivo("C:/Electrónica/Programas QT/Menu/prueba.txt");
    if(archivo.open(QIODevice::ReadWrite)){
       ui->editor->setPlainText(archivo.readAll());

    }
}

void MainWindow::on_actionGuardar_triggered()
{
    QFile archivo("C:/Electrónica/Programas QT/Menu/prueba.txt");
    archivo.open(QIODevice::ReadWrite | QIODevice::Text);
    QTextStream texto(&archivo);
    texto<<ui->editor->toPlainText();
    archivo.close();
}

void MainWindow::on_actionCerrar_triggered()
{
    ui->editor->setPlainText("");
}
