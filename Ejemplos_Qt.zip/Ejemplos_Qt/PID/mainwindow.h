#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QMessageBox>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QSerialPort *arduino;
    QByteArray dato;
    //QString bufferRX;
    QByteArray bufferRX;


private slots:
    void on_horizontalSlider_valueChanged(int value);
    void LeerSerial();
    void on_pushButton_2_clicked();
    void on_ajustarPID_clicked();
    void on_dial_kp_valueChanged(int value);
    void on_dial_ki_valueChanged(int value);
    void on_dial_kd_valueChanged(int value);

private:
    Ui::MainWindow *ui;
    bool bandera = false;
    bool error = false;
    //uint8_t ajuste;
};

#endif // MAINWINDOW_H
