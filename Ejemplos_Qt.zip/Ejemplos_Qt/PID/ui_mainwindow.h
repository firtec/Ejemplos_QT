/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDial>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QFrame *panel1;
    QDial *dial_kp;
    QDial *dial_ki;
    QDial *dial_kd;
    QLCDNumber *lcdkp;
    QLCDNumber *lcdki;
    QLCDNumber *lcdkd;
    QLabel *label;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *label_4;
    QFrame *line;
    QLCDNumber *lcdsp;
    QSlider *horizontalSlider;
    QPushButton *ajustarPID;
    QLabel *label_5;
    QFrame *frame_2;
    QComboBox *baudBox;
    QComboBox *puerto;
    QPushButton *pushButton_2;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_6;
    QFrame *frame_3;
    QLabel *label_lm35;
    QLabel *label_7;
    QLabel *label_9;
    QMenuBar *menuBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(640, 480);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        panel1 = new QFrame(centralWidget);
        panel1->setObjectName(QString::fromUtf8("panel1"));
        panel1->setGeometry(QRect(50, 60, 261, 381));
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(85, 170, 255, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        panel1->setPalette(palette);
        panel1->setFrameShape(QFrame::Panel);
        panel1->setFrameShadow(QFrame::Raised);
        panel1->setLineWidth(3);
        dial_kp = new QDial(panel1);
        dial_kp->setObjectName(QString::fromUtf8("dial_kp"));
        dial_kp->setGeometry(QRect(30, 220, 50, 64));
        dial_kp->setCursor(QCursor(Qt::PointingHandCursor));
        dial_kp->setMaximum(9);
        dial_kp->setValue(8);
        dial_kp->setSliderPosition(8);
        dial_ki = new QDial(panel1);
        dial_ki->setObjectName(QString::fromUtf8("dial_ki"));
        dial_ki->setGeometry(QRect(110, 220, 50, 64));
        dial_ki->setCursor(QCursor(Qt::PointingHandCursor));
        dial_ki->setMaximum(9);
        dial_ki->setValue(2);
        dial_kd = new QDial(panel1);
        dial_kd->setObjectName(QString::fromUtf8("dial_kd"));
        dial_kd->setGeometry(QRect(180, 220, 50, 64));
        dial_kd->setCursor(QCursor(Qt::PointingHandCursor));
        dial_kd->setMaximum(9);
        dial_kd->setValue(1);
        lcdkp = new QLCDNumber(panel1);
        lcdkp->setObjectName(QString::fromUtf8("lcdkp"));
        lcdkp->setGeometry(QRect(40, 192, 41, 31));
        lcdkp->setDigitCount(2);
        lcdkp->setSegmentStyle(QLCDNumber::Flat);
        lcdkp->setProperty("value", QVariant(8.000000000000000));
        lcdki = new QLCDNumber(panel1);
        lcdki->setObjectName(QString::fromUtf8("lcdki"));
        lcdki->setGeometry(QRect(110, 192, 41, 31));
        lcdki->setDigitCount(2);
        lcdki->setSegmentStyle(QLCDNumber::Flat);
        lcdki->setProperty("value", QVariant(2.000000000000000));
        lcdkd = new QLCDNumber(panel1);
        lcdkd->setObjectName(QString::fromUtf8("lcdkd"));
        lcdkd->setGeometry(QRect(180, 192, 41, 31));
        lcdkd->setDigitCount(2);
        lcdkd->setSegmentStyle(QLCDNumber::Flat);
        lcdkd->setProperty("value", QVariant(1.000000000000000));
        label = new QLabel(panel1);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 270, 91, 31));
        QPalette palette1;
        QBrush brush2(QColor(0, 0, 0, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Active, QPalette::WindowText, brush2);
        palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush2);
        QBrush brush3(QColor(120, 120, 120, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush3);
        label->setPalette(palette1);
        QFont font;
        font.setPointSize(10);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(panel1);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 130, 241, 31));
        QFont font1;
        font1.setPointSize(16);
        label_3->setFont(font1);
        label_3->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(panel1);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(100, 270, 71, 31));
        QPalette palette2;
        palette2.setBrush(QPalette::Active, QPalette::WindowText, brush2);
        palette2.setBrush(QPalette::Inactive, QPalette::WindowText, brush2);
        palette2.setBrush(QPalette::Disabled, QPalette::WindowText, brush3);
        label_2->setPalette(palette2);
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignCenter);
        label_4 = new QLabel(panel1);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(170, 270, 71, 31));
        QPalette palette3;
        palette3.setBrush(QPalette::Active, QPalette::WindowText, brush2);
        palette3.setBrush(QPalette::Inactive, QPalette::WindowText, brush2);
        palette3.setBrush(QPalette::Disabled, QPalette::WindowText, brush3);
        label_4->setPalette(palette3);
        label_4->setFont(font);
        label_4->setAlignment(Qt::AlignCenter);
        line = new QFrame(panel1);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(10, 155, 241, 31));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        lcdsp = new QLCDNumber(panel1);
        lcdsp->setObjectName(QString::fromUtf8("lcdsp"));
        lcdsp->setGeometry(QRect(90, 20, 81, 51));
        lcdsp->setDigitCount(2);
        lcdsp->setProperty("value", QVariant(25.000000000000000));
        lcdsp->setProperty("intValue", QVariant(25));
        horizontalSlider = new QSlider(panel1);
        horizontalSlider->setObjectName(QString::fromUtf8("horizontalSlider"));
        horizontalSlider->setGeometry(QRect(20, 80, 221, 41));
        horizontalSlider->setCursor(QCursor(Qt::PointingHandCursor));
        horizontalSlider->setAutoFillBackground(false);
        horizontalSlider->setMinimum(0);
        horizontalSlider->setMaximum(40);
        horizontalSlider->setValue(25);
        horizontalSlider->setOrientation(Qt::Horizontal);
        horizontalSlider->setTickPosition(QSlider::TicksBelow);
        ajustarPID = new QPushButton(panel1);
        ajustarPID->setObjectName(QString::fromUtf8("ajustarPID"));
        ajustarPID->setEnabled(false);
        ajustarPID->setGeometry(QRect(30, 310, 201, 41));
        QFont font2;
        font2.setPointSize(14);
        font2.setBold(true);
        font2.setWeight(75);
        ajustarPID->setFont(font2);
        ajustarPID->setCursor(QCursor(Qt::PointingHandCursor));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(50, 10, 261, 41));
        QFont font3;
        font3.setPointSize(22);
        label_5->setFont(font3);
        label_5->setAlignment(Qt::AlignCenter);
        frame_2 = new QFrame(centralWidget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setGeometry(QRect(330, 60, 261, 191));
        QPalette palette4;
        palette4.setBrush(QPalette::Active, QPalette::Base, brush);
        palette4.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette4.setBrush(QPalette::Active, QPalette::AlternateBase, brush1);
        palette4.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette4.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush1);
        palette4.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette4.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette4.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        frame_2->setPalette(palette4);
        frame_2->setFrameShape(QFrame::Panel);
        frame_2->setFrameShadow(QFrame::Raised);
        frame_2->setLineWidth(3);
        baudBox = new QComboBox(frame_2);
        baudBox->setObjectName(QString::fromUtf8("baudBox"));
        baudBox->setGeometry(QRect(18, 51, 81, 31));
        QFont font4;
        font4.setPointSize(11);
        font4.setBold(true);
        font4.setWeight(75);
        baudBox->setFont(font4);
        baudBox->setCursor(QCursor(Qt::PointingHandCursor));
        puerto = new QComboBox(frame_2);
        puerto->setObjectName(QString::fromUtf8("puerto"));
        puerto->setGeometry(QRect(158, 50, 81, 31));
        puerto->setFont(font4);
        puerto->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_2 = new QPushButton(frame_2);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setEnabled(true);
        pushButton_2->setGeometry(QRect(30, 120, 201, 41));
        pushButton_2->setFont(font2);
        pushButton_2->setCursor(QCursor(Qt::PointingHandCursor));
        label_10 = new QLabel(frame_2);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(20, 15, 71, 31));
        label_10->setFont(font);
        label_10->setAlignment(Qt::AlignCenter);
        label_11 = new QLabel(frame_2);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(150, 20, 91, 21));
        label_11->setFont(font);
        label_11->setAlignment(Qt::AlignCenter);
        label_12 = new QLabel(frame_2);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(110, 10, 41, 41));
        label_12->setStyleSheet(QString::fromUtf8("border-image: url(:/arduino1.ico);"));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(330, 10, 261, 41));
        label_6->setFont(font3);
        label_6->setAlignment(Qt::AlignCenter);
        frame_3 = new QFrame(centralWidget);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(330, 300, 261, 71));
        QPalette palette5;
        palette5.setBrush(QPalette::Active, QPalette::Base, brush);
        palette5.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette5.setBrush(QPalette::Active, QPalette::AlternateBase, brush1);
        palette5.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette5.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette5.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush1);
        palette5.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette5.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette5.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        frame_3->setPalette(palette5);
        frame_3->setFrameShape(QFrame::Panel);
        frame_3->setFrameShadow(QFrame::Raised);
        frame_3->setLineWidth(3);
        label_lm35 = new QLabel(frame_3);
        label_lm35->setObjectName(QString::fromUtf8("label_lm35"));
        label_lm35->setGeometry(QRect(6, 9, 251, 51));
        QPalette palette6;
        QBrush brush4(QColor(255, 0, 0, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette6.setBrush(QPalette::Active, QPalette::WindowText, brush4);
        palette6.setBrush(QPalette::Inactive, QPalette::WindowText, brush4);
        palette6.setBrush(QPalette::Disabled, QPalette::WindowText, brush3);
        label_lm35->setPalette(palette6);
        QFont font5;
        font5.setPointSize(26);
        label_lm35->setFont(font5);
        label_lm35->setAlignment(Qt::AlignCenter);
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(330, 250, 261, 41));
        label_7->setFont(font3);
        label_7->setAlignment(Qt::AlignCenter);
        label_9 = new QLabel(centralWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(350, 380, 231, 81));
        label_9->setStyleSheet(QString::fromUtf8("border-image: url(:/Futuro_Tecnologico.png);"));
        label_9->setAlignment(Qt::AlignCenter);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 640, 21));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", " Control PID con Arduino", nullptr));
        label->setText(QApplication::translate("MainWindow", "Proporcional", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "Set Point", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "Integral", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "Derivativo", nullptr));
        ajustarPID->setText(QApplication::translate("MainWindow", "Ajustar PID", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "Ajuste del PID", nullptr));
        pushButton_2->setText(QApplication::translate("MainWindow", "Conectar", nullptr));
        label_10->setText(QApplication::translate("MainWindow", "Baudios", nullptr));
        label_11->setText(QApplication::translate("MainWindow", "Puerto", nullptr));
        label_12->setText(QString());
        label_6->setText(QApplication::translate("MainWindow", "Comunicaciones", nullptr));
        label_lm35->setText(QApplication::translate("MainWindow", "0", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "Temperatura", nullptr));
        label_9->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
