#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    dato.resize(6);
    dato[0]=25;
    dato[1] = 8;
    dato [2] = 2;
    dato [3] = 1;

    Q_FOREACH(QSerialPortInfo port, QSerialPortInfo::availablePorts()) {
                 ui->puerto->addItem(port.portName());
             }
       ui->baudBox->addItem(QStringLiteral("1200"), QSerialPort::Baud1200);
       ui->baudBox->addItem(QStringLiteral("2400"), QSerialPort::Baud2400);
       ui->baudBox->addItem(QStringLiteral("4800"), QSerialPort::Baud4800);
       ui->baudBox->addItem(QStringLiteral("9600"), QSerialPort::Baud9600);
       ui->baudBox->addItem(QStringLiteral("2400"), QSerialPort::Baud19200);
       ui->baudBox->addItem(QStringLiteral("38400"), QSerialPort::Baud38400);
       ui->baudBox->addItem(QStringLiteral("57600"), QSerialPort::Baud57600);
       ui->baudBox->addItem(QStringLiteral("115200"), QSerialPort::Baud115200);

          statusBar()->showMessage(tr("Desconectado!"));


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_horizontalSlider_valueChanged(int value)
{
    ui->lcdsp->display(value);
    dato[0] = value & 0xFF;
}

void MainWindow::LeerSerial(){
  arduino->flush();
  bufferRX.clear();
  bufferRX = arduino->read(4);
  ui->label_lm35->setText(bufferRX);

}

void MainWindow::on_pushButton_2_clicked()
{
    if(bandera == false){
                arduino = new QSerialPort(ui->puerto->currentText()); // Puerto asignado con el combo BOX
                arduino->open(QIODevice::ReadWrite);
                if(!arduino->isOpen())
                {
                    error = true;
                    QMessageBox::warning(this, "ERROR", "EL PUERTO YA ESTA ABIERTO O NO EXISTE!!!");
                }
                if(error == false){
                        arduino->clear(QSerialPort::AllDirections);  // Limpar buffer del puerto COMx
                        arduino->open(QIODevice::ReadWrite);
                        arduino->setBaudRate(ui->baudBox->currentData().toInt());
                        arduino->setDataBits(QSerialPort::Data8);
                        arduino->setFlowControl(QSerialPort::NoFlowControl);
                        arduino->setParity(QSerialPort::NoParity);
                        arduino->setStopBits(QSerialPort::OneStop);
                        QObject::connect(arduino, SIGNAL(readyRead()), this, SLOT(LeerSerial()));
                        ui->puerto->setEnabled(false);
                        ui->baudBox->setEnabled(false);
                        ui->ajustarPID->setEnabled(true);
                        bandera = true;
                        arduino->write("c");
                        statusBar()->showMessage(tr("Conectado %1 a %2 baudios, %3 bits, %4 stop, s/p")
                         .arg(arduino->portName()).arg(arduino->baudRate()).arg(arduino->dataBits()).arg(arduino->stopBits()));//.arg(arduino->parity()));

                        ui->pushButton_2->setText("Desconectar");
                        bufferRX.clear();
                       }
                    error = false;
                    }else{
                            arduino->write("c");
                            arduino->clear(QSerialPort::AllDirections);   // Limpar buffer del puerto COMx
                            arduino->close();   // Cerrar el puerto COMx
                            bandera = false;    // Cambiar bandera de estado
                            ui->pushButton_2->setText("Conectar");    // Cambiar texto del boton
                            statusBar()->showMessage(tr("Desconectado!"));  // Cambiar texto en barra de estado
                            ui->label_lm35->setText("0");         // Limpiar indicadores
                            ui->ajustarPID->setEnabled(false);
                            ui->puerto->setEnabled(true);   // Activar selección de puertos
                            ui->baudBox->setEnabled(true);  // Activar selección de baudios
                         }
}

void MainWindow::on_ajustarPID_clicked()
{
    dato [4] = 0x7F;
    arduino->write(dato);
}

void MainWindow::on_dial_kp_valueChanged(int value)
{
 ui->lcdkp->display(value);
 dato[1] = value & 0xFF;
}

void MainWindow::on_dial_ki_valueChanged(int value)
{
    ui->lcdki->display(value);
    dato[2] = value & 0xFF;
}

void MainWindow::on_dial_kd_valueChanged(int value)
{
    ui->lcdkd->display(value);
    dato[3] = value & 0xFF;
}
