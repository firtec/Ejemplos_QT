/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionAbrir;
    QAction *actionCerrar;
    QAction *actionCerrar_3;
    QAction *actionSistema;
    QAction *actionAcerda_de;
    QAction *actionConectar;
    QWidget *centralWidget;
    QMenuBar *menuBar;
    QMenu *menuArchivo;
    QMenu *menuConfigurar;
    QMenu *menuAyuda;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(256, 209);
        actionAbrir = new QAction(MainWindow);
        actionAbrir->setObjectName(QString::fromUtf8("actionAbrir"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/add-file.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAbrir->setIcon(icon);
        actionCerrar = new QAction(MainWindow);
        actionCerrar->setObjectName(QString::fromUtf8("actionCerrar"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/clear.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCerrar->setIcon(icon1);
        actionCerrar_3 = new QAction(MainWindow);
        actionCerrar_3->setObjectName(QString::fromUtf8("actionCerrar_3"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/application-exit.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCerrar_3->setIcon(icon2);
        actionSistema = new QAction(MainWindow);
        actionSistema->setObjectName(QString::fromUtf8("actionSistema"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/settings.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSistema->setIcon(icon3);
        actionAcerda_de = new QAction(MainWindow);
        actionAcerda_de->setObjectName(QString::fromUtf8("actionAcerda_de"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/preguntas-frecuentes.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAcerda_de->setIcon(icon4);
        actionConectar = new QAction(MainWindow);
        actionConectar->setObjectName(QString::fromUtf8("actionConectar"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/chip.ico"), QSize(), QIcon::Normal, QIcon::Off);
        actionConectar->setIcon(icon5);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 256, 21));
        menuArchivo = new QMenu(menuBar);
        menuArchivo->setObjectName(QString::fromUtf8("menuArchivo"));
        menuConfigurar = new QMenu(menuBar);
        menuConfigurar->setObjectName(QString::fromUtf8("menuConfigurar"));
        menuAyuda = new QMenu(menuBar);
        menuAyuda->setObjectName(QString::fromUtf8("menuAyuda"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuArchivo->menuAction());
        menuBar->addAction(menuConfigurar->menuAction());
        menuBar->addAction(menuAyuda->menuAction());
        menuArchivo->addAction(actionAbrir);
        menuArchivo->addAction(actionCerrar);
        menuArchivo->addAction(actionCerrar_3);
        menuConfigurar->addAction(actionSistema);
        menuConfigurar->addAction(actionConectar);
        menuAyuda->addAction(actionAcerda_de);
        mainToolBar->addAction(actionAbrir);
        mainToolBar->addAction(actionCerrar);
        mainToolBar->addAction(actionSistema);
        mainToolBar->addAction(actionAcerda_de);
        mainToolBar->addAction(actionConectar);
        mainToolBar->addAction(actionCerrar_3);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Prueba Men\303\272", nullptr));
        actionAbrir->setText(QApplication::translate("MainWindow", "Abrir", nullptr));
        actionCerrar->setText(QApplication::translate("MainWindow", "Limpiar", nullptr));
        actionCerrar_3->setText(QApplication::translate("MainWindow", "Cerrar", nullptr));
        actionSistema->setText(QApplication::translate("MainWindow", "Sistema", nullptr));
        actionAcerda_de->setText(QApplication::translate("MainWindow", "Acerda de", nullptr));
        actionConectar->setText(QApplication::translate("MainWindow", "Conectar", nullptr));
        menuArchivo->setTitle(QApplication::translate("MainWindow", "Archivo", nullptr));
        menuConfigurar->setTitle(QApplication::translate("MainWindow", "Configurar", nullptr));
        menuAyuda->setTitle(QApplication::translate("MainWindow", "Ayuda", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
